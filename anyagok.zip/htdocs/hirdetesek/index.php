<?php
require 'template.php';
header_load();
echo "Kovács András";
footer_load();

?>